------------------------------------------------------------------------
				(Rubix)

Description: 

Given a zip file, but is it actually a zip file?

Category: Steganography

difficulty: baby

------------------------------------------------------------------------- 
