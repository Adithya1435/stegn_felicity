------------------------------------------------------------------------
				(Apples)

Description: 

Light Yagami a high school student discovers Death Note, a notebook that
allows him to kill anyone whose name he writes in it. His pursuit of a 
utopian world leads to moral confict and manuplation.

Category: Steganography

difficulty: baby

------------------------------------------------------------------------- 
